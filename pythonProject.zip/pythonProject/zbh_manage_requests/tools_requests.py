# -*- coding: UTF-8 -*-
import requests
import json
# http工具类封装
class tools_requests:

    def __init__(self):
        pass

    def request(self,url,method,headers=None,params=None, content_type=None):
        try:
            if method == 'get':
                result = requests.get(url=url,params=params,headers=headers).json()
                return result
            elif method =='post':
                if content_type == 'application/json':
                    result = requests.post(url=url,json=params,headers=headers).json()
                    return result
                else:
                    result = requests.post(url=url,data=params,headers=headers).json()
                    return result

            else:
                print("目前不支持其它请求方法")

        except Exception as e:
            print("请求报错:{0}".format(e))


if __name__ == '__main__':
    url ="https://dev.est.cicccapital.cn/amarth/api/sysUser/public/Login"
    r = tools_requests()
    data = {"account": "15510161574", "pwd": "123456", "requestSource": "SYSTEM"}
    header = {"Content-Type":"application/json"}
    result = r.request(url,'post',params=json.dumps(data),headers=header)
    print(result)
