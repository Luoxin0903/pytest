# -*- coding: UTF-8 -*-
import unittest
import os

def load_all_case():
    # 加载指定路径的全部测试用例
    # print(os.getcwd())
    # 用例路径，zbh_manage_case
    case_path = os.path.join(os.getcwd(),"zbh_manage_case")
    # print(case_path) 建议确定用例路径
    # pattern匹配脚本名称的规则，top_level_dir 顶层目录名称 默认None
    discover = unittest.defaultTestLoader.discover(case_path,pattern="test*.py",top_level_dir=None)
    print(discover)
    return discover

if __name__ == '__main__':
    runner = unittest.TextTestRunner()
    runner.run(load_all_case())

    # 请求库包安装 pip install requests -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
