# -*- coding: UTF-8 -*-
import unittest
import os
from unittest import suite, TestCase, TestSuite
import zbh_manage_case
# from zbh_manage_case.auditList_testCase import auditList_testCase
# from zbh_manage_case.index_testCase import index_testCase
# from zbh_manage_case.login_testCase import login_testCase
# from zbh_manage_case.manageList_testCase import manageList_testCase
# from zbh_manage_case.orgList_testCase import orgList_testCase
# from zbh_manage_case.projectClues_testCase import projectClues_testCase
# from zbh_manage_case.saveProject_testCase import saveProject_testCase

def load_all_case():
    # 加载指定路径的全部测试用例
    # print(os.getcwd())
    # 用例路径，zbh_manage_case
    # 构建测试套件
    # suite = unittest.TestCase()
    case_path = os.path.join(os.getcwd(),"zbh_manage_case")
    print(case_path)
    # pattern匹配脚本名称的规则，top_level_dir 顶层目录名称 默认None
    discover = unittest.defaultTestLoader.discover(case_path, pattern="*testCase.py", top_level_dir=None)
    print(discover)
    # for zbh_manage_case in discover:
    #     suite.addTests(zbh_manage_case)
    return discover
    # 调用case方法
    # testCase1 = login_testCase.login_testCase.testUserlogin()

if __name__ == '__main__':


    # 用例执行顺序
    # suite.addTest(login_testCase("testUserlogin"))
    # suite.addTest(index_testCase("testIndexMenuDisplay"))
    # suite.addTest(manageList_testCase("testManageList"))
    # suite.addTest(auditList_testCase("testAuditList"))
    # suite.addTest(projectClues_testCase("testProjectText"))
    # suite.addTest(saveProject_testCase("testSaveProject"))
    # suite.addTest(orgList_testCase("testOrgList"))
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(load_all_case())

    # 请求库包安装 pip install requests -i http://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
