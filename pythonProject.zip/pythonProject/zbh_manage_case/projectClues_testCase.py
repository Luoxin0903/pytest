# -*- coding: UTF-8 -*-
import time
import unittest
import requests
import json

from zbh_manage_case import login_testCase
from zbh_manage_requests import tools_requests

host = "https://dev.est.cicccapital.cn/"

class projectClues_testCase(unittest.TestCase):
    def setUp(self):
        print("执行开始")
    def testProjectText(self):
        # 商机详情页展示
        Token = login_testCase.login_testCase.testUserlogin(self)
        request = tools_requests.tools_requests()
        # data = {"projectClueId":"a9adcfaf-326f-4287-8058-84ce28230b3a","ids":"ALL_PROJECT","projectStatusList":"ALL_STATUS","page":0,"size":9999}
        # url = host + "/amarth/api/projectNotes/web/getALlAcceptNote"
        heards ={ "token":Token}
        response = request.request("https://dev.est.cicccapital.cn/amarth/api/projectNotes/web/getALlAcceptNote?projectClueId=a9adcfaf-326f-4287-8058-84ce28230b3a&ids=ALL_PROJECT&projectStatusList=ALL_STATUS&page=0&size=9999", 'get',heards)
        print(response)
        self.assertTrue(len(response['data']) > 0, "异常：无数据返回")
        print("数据正常返回")
        self.assertEqual(response['code'], 0, "业务状态异常")
        print("业务状态正常code：0")
        self.assertEqual(response['msg'], "成功", "列表查询不成功")
        print("商机详情页请求成功+商机ID：a9adcfaf-326f-4287-8058-84ce28230b3a")
    def tearDown(self):
        time.sleep(60)
        print("执行结束")

if __name__ == '__main__':
    unittest.main(verbosity=2)