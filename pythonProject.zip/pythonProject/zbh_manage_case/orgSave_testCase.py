# -*- coding: UTF-8 -*-
import time
import unittest
import requests
import json
import login_testCase
from zbh_manage_case import login_testCase
from zbh_manage_requests import tools_requests

host = "https://dev.est.cicccapital.cn"
class orgSave_testCase(unittest.TestCase):
    def setUp(self):
        print("执行开始")
        # 商机新建提交验证

    def testSaveOrg(self):
        Token = login_testCase.login_testCase.testUserlogin(self)
        request = tools_requests.tools_requests()
        url = host + "/amarth/api/org/save"
        headers = {"Content-Type": "application/json", "token": Token}
        param = {
            "name": "测试",
            "types": [
                "ENTERPRISE"
                        ],
            "secondTypes": [
                "venturecompany"
                        ],
            "orgInfo": "测试",
            "logo": "https://dev.est.cicccapital.cn/amarth/api/files/public/2218966c-815a-4f34-a394-725fac41f64e",
            "createEnterpriseSpace": "false"
}

        response = request.request(url, 'post', params=json.dumps(param), headers=headers)
        print(response)
        name = param.get('name')
        print("机构新增成功 路径：/amarth/api/org/save  "+ name)


    def tearDown(self):
        time.sleep(5)
        print("执行结束")


if __name__ == '__main__':
    unittest.main(verbosity=2)