# -*- coding: UTF-8 -*-
import time
import unittest
import requests
import json
from zbh_manage_case import login_testCase
from zbh_manage_requests import tools_requests

host = "https://dev.est.cicccapital.cn/"

class manageList_testCase(unittest.TestCase):
    def setUp(self):
        print("执行开始")
    def testManageList(self):
        # 商机管理列表展示
        Token = login_testCase.login_testCase.testUserlogin(self)
        request = tools_requests.tools_requests()
        url = host + "/amarth/api/projectClues/manageList"
        heards = {"Content-Type": "application/json", "Token":
           Token}
        param = {"pape": "0", "size": "10"}
        response = request.request(url, 'post', params=json.dumps(param), headers=heards)
        print(response)
        self.assertTrue(len(response['data']) > 0, "异常：无数据返回")
        print("数据正常返回")
        self.assertEqual(response['code'], 0, "业务状态异常")
        print("业务状态正常code：0")
        self.assertEqual(response['msg'], "成功", "列表查询不成功")
        print("商机列表接口请求成功+/amarth/api/projectClues/manageList")
    def tearDown(self):
        time.sleep(60)
        print("执行结束")

if __name__ == '__main__':
    unittest.main(verbosity=2)