# -*- coding: UTF-8 -*-
import time
import unittest
import requests
import json

from zbh_manage_case import login_testCase
from zbh_manage_requests import tools_requests

host = "https://dev.est.cicccapital.cn"


class saveProject_testCase(unittest.TestCase):
    def setUp(self):
        print("执行开始")
        # 商机新建提交验证
    def testSaveProject(self):
        Token = login_testCase.login_testCase.testUserlogin(self)
        request = tools_requests.tools_requests()
        url = host + "/amarth/api/projectClues/save"
        headers = {"Content-Type": "application/json","token": Token}
        param = {
            "country": "中国",
            "aimsCompanyId": "62874a7c5193a7c5ded9b64e",
            "jingDataId": 22514554,
            "dockingPersons": [
                {
                    "id": "18612116031",
                    "deptId": "60",
                    "teamId": "542",
                    "orderBy": 0
                }
            ],
            "creator": {
                "id": "string",
                "departmentId": "string",
                "teamId": "string"
            },
            "type": "PROJECT_PROPOSAL",
            "status": "NEGOTIATING",
            "name": "北京中科微澜科技有限公司",
            "underlying": "北京中科微澜科技有限公司",
            "description": "安全自动化防御平台提供商",
            "baseIntroduction": "中科微澜是一家安全自动化防御平台提供商，将知识图谱等人工智能技术应用于网络安全领域，自研了VulGraph漏洞图谱，通过智能化的漏洞管理建立动态防御平台Vtopia"
                                "，提升企业对安全威胁的防护能力。",
            "primaryIndustry": "MC",
            "secondIndustry": "IYC",
            "sourceDate": "2025-08-26",
            "sourceParty": "测试",
            "acquireSource": "WM_RECOMMEND",
            "provinceCode": "110000",
            "cityCode": "110100",
            "areaCode": "110108",
            "attachmentJson": "[]",
            "showRange": "CICC",
            "range": "TEAM",
            "city": [
                "中国",
                "110000",
                "110100",
                "110108"
            ],
            "simulateAmount": 0,
            "valuation": 0,
            "branchCompany": "[[]]",
            "branchCompanyStr": "[[]]",
            "industryAddress": "[[]]",
            "industryAddressStr": "[[]]"

        }
        response = request.request(url, 'post', params=json.dumps(param), headers=headers)
        print(response)
        # self.assertTrue(len(response['data']) > 0, "异常：无数据返回")
        # print("数据正常返回")
        # self.assertEqual(response['code'], 0, "业务状态异常")
        # print("业务状态正常code：0")
        # self.assertEqual(response['msg'], "成功", "列表查询不成功")
        name = param.get('name')
        print("商机新增成功 路径：/amarth/api/projectClues/save"+"商机名称  "+ name)
    def tearDown(self):
        time.sleep(60)
        print("执行结束")
    if __name__ == '__main__':
        unittest.main(verbosity=2)
