import pytest

class Test_py:
    @pytest.mark.smoke
    def test_py01(self):
        print("ces01")

    def test_py02(self):
        print("ces02")

    @pytest.mark.smoke
    def test_py03(self):
        print("ces03")